# Design Space — Design System

> "DSGN Studio" — a cozy, warm, multi-page design studio for putting words and shapes onto a canvas. The app brands itself as **Design Space** in the dashboard and **DSGN Studio** in the editor chrome.

This design system documents Design Space's visual language and provides assets, tokens, and UI kit components for prototyping or recreating its surfaces.

---

## Sources

This system was reverse-engineered from a single attached source:

- **Codebase** — local React + TypeScript app at `src/` (Vite + Tailwind + Fabric.js + Zustand). Read-only mount.
  - Global CSS / tokens: `src/index.css`
  - Theme engine: `src/editor/state/uiThemeStore.ts`
  - Editor shell: `src/editor/components/EditorShell.tsx`
  - Dashboard: `src/editor/components/ProjectDashboard.tsx`
  - Status bar: `src/editor/components/StatusBar.tsx`
  - ~50 editor components under `src/editor/components/`

No Figma, slide decks, or external brand documents were provided. Iconography is **Lucide** (the codebase uses `lucide-react` exclusively).

---

## Product context

Design Space is a single-product offering: an in-browser visual design tool. It has two main surfaces:

1. **Project Dashboard** — landing page where the user creates a new project from a preset (US Letter, social sizes) or opens a recent one. Soft, paper-like card on a warm cream background.
2. **Editor Shell** — full-screen canvas with chrome on all four sides:
   - Top header: "DSGN Studio" wordmark, project name, file menu, undo/redo, tool group, fill/canvas color, project switcher, export.
   - Left rail: Workspace nav strip (Shapes, Insert, Assets) with a panel that slides out.
   - Right rail: Tabbed Layers / Properties / Style panel.
   - Footer status bar: dimensions, units, zoom, safe zones, save status.
   - Page strip along the bottom for multi-page docs.

The codebase also includes a `BrandKit`, a `VisionBoard` mood-board surface, theme presets ("Midnight", "Hedge", "Dawn") and a project preset modal.

---

## Index — what's in this folder

```
README.md                    ← you are here
SKILL.md                     ← Claude Code skill manifest
colors_and_type.css          ← CSS custom properties (color, type, spacing, shadow)
fonts/                       ← webfont CSS imports (Inter, Space Grotesk via Google Fonts)
assets/
  ├── logo-dsgn-mark.svg     ← compact "DS" sparkle mark (recreated; flag below)
  ├── logo-design-space.svg  ← full wordmark with sparkle
  └── icon-strategy.md       ← notes on Lucide icon usage
preview/                     ← Design System tab cards (small specimens)
ui_kits/
  └── design-space/
       ├── README.md
       ├── index.html        ← interactive editor recreation
       ├── Header.jsx
       ├── ProjectDashboard.jsx
       ├── EditorShell.jsx
       ├── ToolGroup.jsx
       ├── LayersPanel.jsx
       ├── StatusBar.jsx
       ├── PageStrip.jsx
       └── tokens.js
```

> No slide template was provided, so `slides/` is intentionally absent.

---

## Content fundamentals

The voice of Design Space is **calm, crafty, and slightly precious** — leaning into the warm-paper / atelier vibe. Several specific patterns:

- **Tiny ALL-CAPS labels with wide tracking** are the dominant chrome treatment. Tailwind class `uppercase tracking-widest` shows up on virtually every button, tab, badge, status pill, and section header. Font-size is usually `text-[10px]` or `text-[11px]`.
- **Title Case for proper nouns** ("Design Space", "Brand Kit", "Vision Board", "DSGN Studio", "Midnight", "Hedge", "Dawn"). Page H1 is `tracking-[0.02em]` — only barely loosened.
- **Sentence case for body copy and toasts**, e.g. _"Multi-page design studio"_, _"You have unsaved changes."_, _"Editor is still initializing. Please try again."_, _"Pin designs, add images, or collect colors to build your mood board."_
- **Short, declarative.** Toast example: _"Design pinned to vision board"_. No exclamation marks. No marketing fluff.
- **Pronoun:** "you" addressing the user; the app refers to itself by name ("Design Space closes", "Design Space is still initializing"), never "we".
- **No emoji.** None found in the codebase. Status uses Lucide icons (`AlertTriangle`, `Sparkles`, `Pin`).
- **Casing of labels:**
  - Buttons / pills / nav items / tabs → `UPPERCASE TRACKING-WIDEST`
  - Section headings within panels → `UPPERCASE TRACKING-WIDEST` at 10–11px
  - Page-level H1s → Title Case (e.g. "Design Space")
  - Body text → Sentence case
- **Specific copy specimens** (lift these for examples):
  - Hero subhead: _"Multi-page design studio"_
  - Empty state: _"Your vision board is empty"_ / _"Pin designs, add images, or collect colors to build your mood board."_
  - Action labels: _"New Project"_, _"Open Project"_, _"Pin Design"_, _"Add Color"_, _"Add Heading"_, _"Add Body Text"_, _"Vibe Settings"_, _"Brand"_
  - Tool tooltips: _"Select (V)"_, _"Pan (H)"_, _"Quick Open (⌘K)"_

The word **"vibe"** is canon — see `Vibe Settings`, `VibeCard`. It's the only place the system winks at itself.

---

## Visual foundations

### Colors

Three theme presets, each warm/earthy. Default is **Midnight** (a misnomer — it's actually a warm cream).

| Token | Midnight (default) | Hedge | Dawn |
|---|---|---|---|
| `--ui-bg` | `#f6efe6` warm cream | `#eef1ea` sage cream | `#fbf5f1` blush cream |
| `--ui-panel` | `rgba(255, 249, 241, .84)` | `rgba(247, 251, 245, .84)` | `rgba(255, 250, 246, .88)` |
| `--ui-text` / `--ui-panel-text` | `#4a3f38` warm ink | `#405046` forest ink | `#4d3f3f` plum ink |
| `--ui-accent` (= `--brand-primary`) | `#b8878f` dusty rose | `#8ea591` muted sage | `#c59aa0` blush rose |
| `--ui-border` | `rgba(138, 110, 92, .24)` | `rgba(114, 138, 119, .26)` | `rgba(171, 133, 126, .24)` |

Body background is a **radial gradient**, not a solid: `radial-gradient(circle at 20% 10%, #fff8ef 0%, #fbf7f2 35%, #efe6dc 100%)`. The app feels lit from the upper-left.

There's also a "cozy warmth palette" of named colors used throughout:

```
--warm-cream:  #f4eee5
--warm-ivory:  #fbf7f2
--warm-taupe:  #b89f8c
--warm-sage:   #8fa28d
--warm-rose:   #c4969a
--warm-ink:    #463a34
```

Shadows are **all warm-tinted**, never neutral grey:

```
--warm-shadow:        0 16px 38px rgba(56, 40, 33, .18);
--ui-shadow-soft:     0 12px 28px rgba(74, 56, 45, .10);
--ui-shadow-strong:   0 18px 42px rgba(74, 56, 45, .16);
--popover-shadow:     0 18px 46px rgba(56, 40, 33, .16);
--toolbar-shadow:     0 12px 28px rgba(56, 40, 33, .14);
```

### Typography

- **UI font:** Inter (300/400/500/600/700) loaded from Google Fonts. `--font-ui`.
- **Display font:** Space Grotesk, only declared as `--font-display` — but the codebase doesn't actually `@import` it. Treat Space Grotesk as the intended display face; this design system imports it explicitly. ⚠️ **Substitution flag**: in source, only Inter is loaded; Space Grotesk falls back to Inter. We're being faithful to the declared intent and loading both.
- Type is generally **small and tight**. Most labels are 10–13 px. The dashboard H1 is the only big type ("Design Space" at `text-4xl`).
- **`uppercase tracking-widest`** is the brand's defining type treatment for chrome. Use it on buttons, tabs, badges, status pills, panel section headers.
- **No display-weight variations**; Inter at 500/600 carries the load. Bold italic isn't used.

### Spacing & radii

Geometry leans **friendly and rounded**, never sharp.

| Token | Value | Used for |
|---|---|---|
| `--radius-pill` | `9999px` | toolbar pills, chrome buttons (`rounded-full`) |
| `--radius-2xl` | `1rem` (16px) | popovers, large cards, modals |
| `--radius-xl` | `0.75rem` (12px) | inputs, default surfaces |
| `--radius-lg` | `0.5rem` (8px) | small icon buttons, list rows |
| Project dashboard card | `2rem` (32px, "rounded-[2rem]") | hero card |

Control heights are standardized: `--control-height: 32px`, with `28px` (sm) and `40px` (lg) variants.

Toolbar pills use `rounded-full`; chrome buttons are also full-rounded with a wide tracked label inside. Cards inside panels are `rounded-2xl`. Modals are `rounded-2xl`.

### Surfaces & cards

Cards aren't flat — they're **layered, semi-transparent, blurred**.

```
.ui-card-soft     → bg: rgba(255, 251, 246, .78), 1px border, soft shadow
.ui-card-elevated → bg: rgba(255, 253, 249, .94), 1px border, strong shadow
backdrop-filter: blur(12px)  ← --ui-blur
```

The right and left rails use `bg-[color:var(--ui-panel)]/70 backdrop-blur-[var(--ui-blur)]`. The whole feel is **frosted paper on a warm desk**.

### Borders

Always **soft and warm**, never `#ccc`:

- `--ui-border: rgba(138, 110, 92, .24)` (Midnight)
- 1px is the universal stroke width
- Active/selected states bump border to the brand rose at 28–50% opacity, not a saturated line

### Buttons & interactive states

- **Hover:** background nudges up by ~10–15% opacity (`bg-white/5 → bg-white/10` is a recurring move; or `--ui-surface-soft → --ui-surface-strong`). Color shifts from `--ui-panel-text` to `--ui-text`. Shadow grows from soft to strong.
- **Active (pressed):** `transform: translateY(1px)` for soft buttons, `transform: scale(0.97)` for icon buttons. No color flash.
- **Active (selected/toggled):** `.ui-button-active` — border brand-primary @ 28%, bg brand-primary @ 14%, shadow tinted with brand-primary @ 14%.
- **Focus-visible:** 3px outer ring of brand-primary @ 18%, no harsh blue.
- **Disabled:** `opacity: 0.55`, no shadow.
- Icon buttons have a tiny micro-bounce: `:hover scale(1.05)`, `:active scale(0.95)`.

### Animation

- **Three named durations:** `--transition-fast: 150ms ease-out`, `--transition-normal: 200ms ease-out`, `--transition-slow: 300ms ease-in-out`. Most components use `300ms ease-in-out` for color/bg changes; transforms use the fast 150ms.
- **No bounce, no spring, no fancy easing.** Just `ease-out` and `ease-in-out`.
- Transitions apply to: `background`, `color`, `border-color`, `box-shadow`, `transform`, `opacity`. Layout changes are not animated.
- Fades on hover (`.opacity-0 group-hover:opacity-100`) for affordance reveals (e.g. rename pencil icon on project cards).

### Imagery & background

- **No photography is shipped.** No illustrations, either.
- The closest the app comes to imagery is the **warm radial gradient** behind everything and a **24px workspace dot/grid** (`linear-gradient` lines at `rgba(120, 93, 74, .065)`) that shows the canvas paper.
- Where a visual rest is needed, the design uses **negative space and soft shadows**, not images.

### Iconography

- **Lucide icons exclusively**, via `lucide-react`. Stroke 1.5 across the app (`stroke-[1.5]`).
- Common sizes: `w-3 h-3` (status pills), `w-3.5 h-3.5` (tab icons), `w-4 h-4` (buttons, default), `w-5 h-5` (panel headers, larger affordances), `w-6 h-6` (dashboard hero).
- Default tone uses `.icon-muted` (color = `--muted-icon`, transitions to `--brand-primary` on hover). Selected states use `--brand-primary` directly.
- Recurring icons across the editor: `Sparkles, Plus, FolderOpen, Pencil, Eraser, Hand, MousePointer2, Type, Frame, Layers, SlidersHorizontal, Magnet, Grid, PaintBucket, Download, Home, Undo2, Redo2, Search, Keyboard, ChevronUp, ChevronDown, AlertTriangle, Pin, Layout, Palette, ZoomIn, ZoomOut, Maximize2, Trash2, Grid3X3`.
- See `assets/icon-strategy.md` for the full pattern. **No emoji, no Unicode glyph icons.**

### Layout & rules

- **Three-column editor:** 320px left rail (with a 150px nested sub-rail) · flexible center stage · 320px right panel. Both side rails collapse on small screens (`max-w 1023/1279`).
- **Header is full-bleed** with three sections: brand+project (left, min 22rem), tool toolbar pills (centered), chrome (right).
- **Status bar is always 48px** (`h-12`).
- **Canvas/workspace** has its own background: `#efe5d9` with a 24px-grid overlay.

### Use of transparency & blur

- Panels use `bg-[color:var(--ui-panel)]/70` or `/88` + `backdrop-blur-[var(--ui-blur)]` (12px).
- Modals dim the page with `bg-[rgba(58,40,32,0.52)] backdrop-blur-sm` — note the **warm-tinted scrim**, not pure black.
- Toasts use `bg-white/10` overlays on tinted variants.
- Don't go opaque on chrome surfaces — the blur-on-warm look is the point.

### Dont's

- ❌ Don't use cool greys, slate-blue, indigo, or saturated brights. The base palette is exclusively warm beige/rose/sage.
- ❌ Don't use sharp 90° corners on interactive elements. Even tabs have `border-b-2` accents, not solid borders.
- ❌ Don't use heavy display fonts. Inter is the workhorse.
- ❌ Don't use neutral-grey shadows. Always tint with `rgba(56, 40, 33, …)` or `rgba(74, 56, 45, …)`.
- ❌ Don't use emoji.

---

## Iconography

**Library:** Lucide React (`lucide-react`). Imported per-component, e.g. `import { Sparkles, Plus, FolderOpen } from 'lucide-react'`. The codebase ships no custom icon font, no SVG sprite, no PNG icons — everything is Lucide.

**Strategy in this design system:** load Lucide via CDN (icons-as-CSS-mask or inline `<svg>`). For HTML mockups, embed the SVG directly so the warm palette inherits via `currentColor`. See `assets/icon-strategy.md`.

**Stroke / size rules:**
- `stroke-width: 1.5` always
- Sizes follow a tight scale: 12, 14, 16, 20, 24px
- Color via CSS custom property — `currentColor` inherits from button text

**Emoji & Unicode:** never used as iconography. The only Unicode glyphs in source are `×` for close buttons (in a few places) and `−` / `+` for zoom +/–. Don't introduce ⚡ or 🎨 or anything else.

**Logo:**
- The product is named "Design Space" on the dashboard and "DSGN Studio" in the editor — both **wordmarks**, no formal logo file is shipped.
- The closest thing to a logo is a `Sparkles` Lucide icon in a `rounded-2xl` brand-tinted square on the dashboard hero.
- This system ships:
  - `assets/logo-dsgn-mark.svg` — recreated compact mark (Sparkles glyph in a tinted square)
  - `assets/logo-design-space.svg` — full wordmark
- ⚠️ These are recreated, not extracted from a brand kit. Flag this to the user if exact-fidelity is needed.

---

## Caveats

- **No real logo files** were provided. The marks in `assets/` are reconstructed from the in-product `Sparkles` icon and the literal text "Design Space" / "DSGN Studio".
- **Space Grotesk is declared but never loaded** in the source. We load it. Confirm intent with the team.
- **No brand-spec doc, no color names** beyond the variable names. We've inferred palette names like "warm cream", "dusty rose", "muted sage".
- **"Midnight" is not dark.** Don't be surprised — the default theme is warm cream with a dusty-rose accent. There is no actual dark mode.
- **One product surface only.** No marketing site, no docs site, no mobile app exist in the codebase.
