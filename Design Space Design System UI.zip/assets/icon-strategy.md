# Iconography Strategy

## Library
**Lucide.** The codebase imports from `lucide-react` exclusively. No custom icon font, no SVG sprite, no PNG icons exist in `src/`.

## How to use Lucide outside React
- **Inline SVG**: copy any glyph from <https://lucide.dev/icons> directly into your HTML. Use `currentColor` for the stroke so it inherits from the surrounding text color.
- **CDN**: load `https://unpkg.com/lucide@latest/dist/umd/lucide.min.js` and call `lucide.createIcons()` after DOM is ready. Lucide will replace `<i data-lucide="sparkles">` placeholders with inline SVGs.
- **Stroke**: always `stroke-width: 1.5` (matches `stroke-[1.5]` everywhere in the source).
- **Sizes**: 12, 14, 16, 20, 24px — matching Tailwind `w-3 / w-3.5 / w-4 / w-5 / w-6`.

## Tone & color
- Default state uses `--muted-icon` (= `--ui-panel-text`).
- Hover transitions to `--brand-primary` over `--transition-slow` (300ms ease-in-out).
- Selected/active uses `--brand-primary` directly.
- Inside brand-tinted pills, icons inherit the pill's color via `currentColor`.

## Icons in active rotation
Tracked via grep across `src/editor/components/`. These are the icons you'll reach for most:

**Tools (top toolbar):**
`MousePointer2, Pencil, Eraser, Hand, PaintBucket, Type, Magnet, Grid, Frame, Layers, SlidersHorizontal, Undo2, Redo2`

**Chrome (header):**
`Sparkles, Home, Search, Keyboard, Download, Plus, Pencil (rename), ChevronDown, ChevronUp, Folder, FolderOpen, FileText`

**Status & feedback:**
`AlertTriangle, Loader2 (spinning), Pin, Layout`

**Vision board / brand:**
`Grid3X3, Palette, Trash2, Pin, ZoomIn, ZoomOut, Maximize2`

## What is NOT used
- **No emoji.** Zero in the source. Don't introduce 🎨 or ⚡ etc.
- **No Unicode glyph icons** other than:
  - `×` for close (a few places)
  - `−` and `+` in the zoom widget
  - `/` as a separator between brand and project name in the header
- **No custom illustrations** of any kind.
- **No animated icons** — only `Loader2` spins (via `animate-spin`).

## When prototyping HTML
1. Pick the Lucide glyph name from <https://lucide.dev/icons>.
2. Copy the SVG markup, replace `stroke="currentColor"` if it isn't already.
3. Wrap in `<span class="icon-muted">` (or directly inside a button) so color/tone propagates.

```html
<button class="icon-muted" aria-label="Sparkles">
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
       stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
       stroke-linejoin="round">
    <path d="M12 3l1.9 5.1a3 3 0 0 0 2 2L21 12l-5.1 1.9a3 3 0 0 0-2 2L12 21l-1.9-5.1a3 3 0 0 0-2-2L3 12l5.1-1.9a3 3 0 0 0 2-2L12 3z"/>
    <path d="M5 3v4M19 17v4M3 5h4M17 19h4"/>
  </svg>
</button>
```
