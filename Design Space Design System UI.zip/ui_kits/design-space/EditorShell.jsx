// Editor Shell — composes Header / Sidebar / CanvasStage / RightPanel / StatusBar / PageStrip.

const EditorShell = ({ projectName, onProjectsClick }) => {
  const [activeTool, setActiveTool] = React.useState('select');
  const [snap, setSnap] = React.useState(true);
  const [grid, setGrid] = React.useState(false);
  const [activeNav, setActiveNav] = React.useState('shapes');
  const [rightTab, setRightTab] = React.useState('layers');
  const [unit, setUnit] = React.useState('px');
  const [zoom, setZoom] = React.useState(0.7);
  const [safe, setSafe] = React.useState(false);

  const initialLayers = [
    { id: 'l1', name: 'Headline', type: 'text', x: 80, y: 100, text: 'Multi-page studio', fill: '#4a3f38', size: 56, weight: 600, font: 'var(--font-display)' },
    { id: 'l2', name: 'Subhead', type: 'text', x: 80, y: 184, text: 'A cozy place to put words and shapes onto a canvas.', fill: '#7a6a60', size: 18, weight: 400, font: 'var(--font-ui)', tracking: 0 },
    { id: 'l3', name: 'Accent rose', type: 'rect', x: 80, y: 260, w: 200, h: 8, fill: '#b8878f', radius: 4 },
    { id: 'l4', name: 'Sage card', type: 'rect', x: 540, y: 380, w: 220, h: 280, fill: '#8fa28d', radius: 28, opacity: 100 },
    { id: 'l5', name: 'Sparkle', type: 'star', x: 600, y: 440, w: 96, fill: '#fbf7f2' },
    { id: 'l6', name: 'Cream halo', type: 'circle', x: 100, y: 460, w: 200, h: 200, fill: '#f4eee5' },
    { id: 'l7', name: 'Rose dot', type: 'circle', x: 130, y: 530, w: 80, h: 80, fill: '#c4969a' },
  ];
  const [layers, setLayers] = React.useState(initialLayers);
  const [selectedId, setSelectedId] = React.useState('l1');

  const [pages, setPages] = React.useState([
    { id: 'p1', name: 'Page 1' },
    { id: 'p2', name: 'Page 2' },
    { id: 'p3', name: 'Page 3' },
  ]);
  const [activePageIndex, setActivePageIndex] = React.useState(0);

  const handleAddShape = (kind) => {
    const id = 'l' + (layers.length + 1);
    const palette = ['#b8878f', '#8fa28d', '#d6a05a', '#c4969a', '#4a3f38'];
    const fill = palette[layers.length % palette.length];
    const map = {
      rect: { type: 'rect', w: 200, h: 140, radius: 16, fill },
      circle: { type: 'circle', w: 160, h: 160, fill },
      tri: { type: 'rect', w: 160, h: 160, fill, radius: 80 },
      star: { type: 'star', w: 96, fill },
      frame: { type: 'rect', w: 240, h: 160, fill: '#fff', radius: 8 },
      text: { type: 'text', text: 'Add Body Text', size: 24, fill: '#4a3f38', weight: 500, font: 'var(--font-ui)' },
    };
    const seed = map[kind] || map.rect;
    const newLayer = { id, name: kind === 'text' ? 'Text' : kind.charAt(0).toUpperCase() + kind.slice(1), x: 200 + layers.length * 30, y: 220 + layers.length * 30, ...seed };
    setLayers(ls => [...ls, newLayer]);
    setSelectedId(id);
  };

  return (
    <div style={{
      display: 'flex', flexDirection: 'column',
      height: '100vh',
      background: 'radial-gradient(circle at 20% 10%, #fff8ef 0%, #fbf7f2 35%, #efe6dc 100%)',
      color: '#4a3f38',
      fontFamily: 'var(--font-ui)',
    }}>
      <Header
        projectName={projectName}
        onProjectsClick={onProjectsClick}
        activeTool={activeTool} setActiveTool={setActiveTool}
        snap={snap} setSnap={setSnap}
        grid={grid} setGrid={setGrid}
      />
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden', minHeight: 0 }}>
        <Sidebar activeNav={activeNav} setActiveNav={setActiveNav} onAddShape={handleAddShape} />
        <CanvasStage
          width={816} height={1056}
          zoom={zoom}
          gridEnabled={grid}
          layers={layers}
          selectedId={selectedId}
          onSelect={setSelectedId}
        />
        <RightPanel tab={rightTab} setTab={setRightTab} layers={layers} selectedId={selectedId} onSelect={setSelectedId} />
      </div>
      <PageStrip
        pages={pages}
        activeIndex={activePageIndex}
        setActive={setActivePageIndex}
        onAdd={() => setPages(ps => [...ps, { id: 'p' + (ps.length + 1), name: 'Page ' + (ps.length + 1) }])}
        onDelete={(i) => setPages(ps => ps.filter((_, idx) => idx !== i))}
      />
      <StatusBar
        width={816} height={1056}
        unit={unit} setUnit={setUnit}
        zoom={zoom} setZoom={setZoom}
        safe={safe} setSafe={setSafe}
      />
    </div>
  );
};

window.EditorShell = EditorShell;
