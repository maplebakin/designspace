// Chrome buttons — pill-shaped, eyebrow-cased, warm-shadowed.

const chromeBtnStyle = {
  display: 'inline-flex',
  alignItems: 'center',
  gap: 8,
  padding: '8px 16px',
  borderRadius: 9999,
  fontSize: 11,
  letterSpacing: '0.18em',
  textTransform: 'uppercase',
  fontWeight: 500,
  fontFamily: 'inherit',
  background: 'rgba(255, 251, 246, 0.78)',
  border: '1px solid rgba(138, 110, 92, 0.24)',
  color: '#7a6a60',
  boxShadow: '0 12px 28px rgba(74, 56, 45, 0.10)',
  cursor: 'pointer',
  transition: 'all 200ms ease-out',
  whiteSpace: 'nowrap',
};

const ChromeButton = ({ icon: Icon, children, active, primary, onClick, style }) => {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const computed = {
    ...chromeBtnStyle,
    ...(active && {
      background: 'rgba(184, 135, 143, 0.14)',
      borderColor: 'rgba(184, 135, 143, 0.30)',
      color: '#b8878f',
    }),
    ...(primary && {
      background: '#b8878f',
      borderColor: '#b8878f',
      color: '#fff',
    }),
    ...(hover && !primary && !active && {
      background: 'rgba(255, 253, 249, 0.94)',
      color: '#4a3f38',
      boxShadow: '0 18px 42px rgba(74, 56, 45, 0.16)',
    }),
    ...(hover && primary && {
      background: '#a87680',
    }),
    ...(press && { transform: 'translateY(1px)' }),
    ...style,
  };
  return (
    <button
      style={computed}
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setPress(false); }}
      onMouseDown={() => setPress(true)}
      onMouseUp={() => setPress(false)}
    >
      {Icon && <Icon size={14} />}
      {children}
    </button>
  );
};

const IconButton = ({ icon: Icon, active, onClick, title, size = 16 }) => {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const style = {
    width: 32, height: 32,
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
    borderRadius: 8,
    background: active ? 'rgba(184, 135, 143, 0.18)' : (hover ? 'rgba(184, 135, 143, 0.10)' : 'transparent'),
    color: active ? '#b8878f' : (hover ? '#b8878f' : '#7a6a60'),
    border: 'none', cursor: 'pointer',
    transition: 'all 150ms ease-out',
    transform: press ? 'scale(0.95)' : (hover ? 'scale(1.05)' : 'scale(1)'),
  };
  return (
    <button
      title={title}
      style={style}
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setPress(false); }}
      onMouseDown={() => setPress(true)}
      onMouseUp={() => setPress(false)}
    >
      <Icon size={size} />
    </button>
  );
};

const ToolbarGroup = ({ children, spaced }) => (
  <div style={{
    display: 'inline-flex',
    alignItems: 'center',
    gap: spaced ? 2 : 1,
    padding: 4,
    borderRadius: 9999,
    background: 'rgba(255, 251, 246, 0.78)',
    border: '1px solid rgba(138, 110, 92, 0.24)',
    boxShadow: '0 12px 28px rgba(56, 40, 33, 0.14)',
  }}>{children}</div>
);

const ToolbarDivider = () => (
  <div style={{ width: 1, height: 20, background: 'rgba(138, 110, 92, 0.24)', margin: '0 4px' }} />
);

const Eyebrow = ({ children, color = '#7a6a60', size = 10, style }) => (
  <span style={{
    fontSize: size,
    letterSpacing: '0.18em',
    textTransform: 'uppercase',
    fontWeight: 500,
    color,
    ...style,
  }}>{children}</span>
);

Object.assign(window, { ChromeButton, IconButton, ToolbarGroup, ToolbarDivider, Eyebrow });
