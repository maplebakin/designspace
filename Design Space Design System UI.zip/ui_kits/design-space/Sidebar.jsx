// Left rail — NavStrip + active panel. Recreates the editor's two-column left side.

const NAV_ITEMS = [
  { id: 'shapes', label: 'Shapes', icon: 'Square' },
  { id: 'insert', label: 'Insert', icon: 'Plus' },
  { id: 'assets', label: 'Assets', icon: 'Image' },
  { id: 'brand', label: 'Brand', icon: 'Palette' },
  { id: 'pages', label: 'Pages', icon: 'Layout' },
];

const navIconFor = (id) => ({
  shapes: Square, insert: Plus, assets: Image, brand: Palette, pages: Layout,
}[id]);

const NavStripItem = ({ item, active, onClick }) => {
  const [hover, setHover] = React.useState(false);
  const Icon = navIconFor(item.id);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        width: '100%',
        padding: '14px 8px',
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
        background: active ? 'rgba(184, 135, 143, 0.14)' : (hover ? 'rgba(184, 135, 143, 0.08)' : 'transparent'),
        color: active ? '#b8878f' : '#7a6a60',
        border: 'none',
        borderLeft: active ? '2px solid #b8878f' : '2px solid transparent',
        cursor: 'pointer',
        transition: 'all 200ms ease-out',
        fontSize: 9,
        letterSpacing: '0.18em',
        textTransform: 'uppercase',
        fontWeight: 500,
        fontFamily: 'inherit',
      }}
    >
      <Icon size={18} />
      {item.label}
    </button>
  );
};

const ShapesPanelContent = ({ onAdd }) => {
  const shapes = [
    { id: 'rect', label: 'Rectangle', Ic: Square },
    { id: 'circle', label: 'Circle', Ic: Circle },
    { id: 'tri', label: 'Triangle', Ic: Triangle },
    { id: 'star', label: 'Star', Ic: Star },
    { id: 'frame', label: 'Frame', Ic: Frame },
    { id: 'text', label: 'Text', Ic: Type },
  ];
  return (
    <div style={{ padding: 16 }}>
      <Eyebrow size={9}>Quick Add</Eyebrow>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginTop: 10 }}>
        {shapes.map(s => (
          <ShapeChip key={s.id} Icon={s.Ic} label={s.label} onClick={() => onAdd(s.id)} />
        ))}
      </div>

      <div style={{ marginTop: 22 }}>
        <Eyebrow size={9}>Recent Colors</Eyebrow>
        <div style={{ display: 'flex', gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
          {['#b8878f', '#8fa28d', '#d6a05a', '#4a3f38', '#fbf7f2', '#c75858'].map(c => (
            <span key={c} style={{
              width: 26, height: 26, borderRadius: 9999,
              background: c, border: '1px solid rgba(138, 110, 92, 0.24)',
              cursor: 'pointer',
            }} />
          ))}
        </div>
      </div>
    </div>
  );
};

const ShapeChip = ({ Icon, label, onClick }) => {
  const [hover, setHover] = React.useState(false);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
        padding: '14px 6px',
        borderRadius: 12,
        background: hover ? 'rgba(255, 253, 249, 0.94)' : 'rgba(255, 251, 246, 0.78)',
        border: '1px solid rgba(138, 110, 92, 0.24)',
        boxShadow: hover ? '0 18px 42px rgba(74, 56, 45, 0.16)' : '0 12px 28px rgba(74, 56, 45, 0.10)',
        color: hover ? '#b8878f' : '#7a6a60',
        cursor: 'pointer',
        transition: 'all 200ms ease-out',
        fontFamily: 'inherit',
      }}
    >
      <Icon size={20} />
      <Eyebrow size={9}>{label}</Eyebrow>
    </button>
  );
};

const InsertPanelContent = () => (
  <div style={{ padding: 16 }}>
    <Eyebrow size={9}>Text</Eyebrow>
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 10 }}>
      <PanelRow label="Add Heading" sub="48 / Inter SemiBold" />
      <PanelRow label="Add Subheading" sub="24 / Inter SemiBold" />
      <PanelRow label="Add Body Text" sub="14 / Inter Regular" />
    </div>
    <div style={{ marginTop: 18 }}>
      <Eyebrow size={9}>From Library</Eyebrow>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 10 }}>
        <PanelRow label="Pin Design" />
        <PanelRow label="Add Color" />
        <PanelRow label="Add Image" />
      </div>
    </div>
  </div>
);

const PanelRow = ({ label, sub }) => {
  const [hover, setHover] = React.useState(false);
  return (
    <button
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        textAlign: 'left',
        padding: '10px 12px',
        borderRadius: 12,
        background: hover ? 'rgba(255, 253, 249, 0.94)' : 'rgba(255, 251, 246, 0.50)',
        border: '1px solid rgba(138, 110, 92, 0.18)',
        color: '#4a3f38',
        cursor: 'pointer',
        transition: 'all 150ms ease-out',
        fontFamily: 'inherit',
      }}
    >
      <Eyebrow size={10} color={hover ? '#b8878f' : '#4a3f38'}>{label}</Eyebrow>
      {sub && <div style={{ fontSize: 11, color: '#7a6a60', marginTop: 4, letterSpacing: 0, textTransform: 'none', fontFamily: 'var(--font-mono)' }}>{sub}</div>}
    </button>
  );
};

const Sidebar = ({ activeNav, setActiveNav, onAddShape }) => (
  <aside style={{
    width: 320,
    background: 'rgba(255, 249, 241, 0.70)',
    backdropFilter: 'blur(12px)',
    borderRight: '1px solid rgba(138, 110, 92, 0.24)',
    display: 'flex', flexDirection: 'column',
    flexShrink: 0,
  }}>
    <div style={{ padding: '12px 16px', borderBottom: '1px solid rgba(138, 110, 92, 0.18)' }}>
      <Eyebrow size={10}>Workspace</Eyebrow>
      <div style={{ marginTop: 4 }}><Eyebrow size={9} color="rgba(122, 106, 96, 0.7)">Choose a panel to work faster</Eyebrow></div>
    </div>
    <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
      <div style={{ width: 80, borderRight: '1px solid rgba(138, 110, 92, 0.18)', overflowY: 'auto' }}>
        {NAV_ITEMS.map(item => (
          <NavStripItem key={item.id} item={item} active={activeNav === item.id} onClick={() => setActiveNav(item.id)} />
        ))}
      </div>
      <div style={{ flex: 1, overflowY: 'auto' }}>
        <div style={{ padding: '12px 16px', borderBottom: '1px solid rgba(138, 110, 92, 0.18)' }}>
          <Eyebrow size={10}>{NAV_ITEMS.find(n => n.id === activeNav)?.label}</Eyebrow>
        </div>
        {activeNav === 'shapes' && <ShapesPanelContent onAdd={onAddShape} />}
        {activeNav === 'insert' && <InsertPanelContent />}
        {activeNav === 'assets' && <div style={{ padding: 16 }}><Eyebrow size={9}>No assets uploaded.</Eyebrow></div>}
        {activeNav === 'brand' && <div style={{ padding: 16 }}><Eyebrow size={9}>Brand kit</Eyebrow></div>}
        {activeNav === 'pages' && <div style={{ padding: 16 }}><Eyebrow size={9}>Manage pages below.</Eyebrow></div>}
      </div>
    </div>
  </aside>
);

window.Sidebar = Sidebar;
