// Top toolbar — DSGN Studio wordmark + project name + tools + chrome.

const Header = ({ projectName, onProjectsClick, activeTool, setActiveTool, snap, setSnap, grid, setGrid }) => (
  <header style={{
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '0 20px',
    height: 56,
    background: 'rgba(255, 249, 241, 0.84)',
    backdropFilter: 'blur(12px)',
    borderBottom: '1px solid rgba(138, 110, 92, 0.24)',
    flexShrink: 0,
    zIndex: 10,
  }}>
    {/* Left — brand + project */}
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, minWidth: '22rem' }}>
      <Eyebrow size={11} color="#4a3f38" style={{ fontWeight: 600 }}>DSGN Studio</Eyebrow>
      <span style={{ color: 'rgba(138, 110, 92, 0.5)', fontSize: 12, userSelect: 'none' }}>/</span>
      <span style={{ fontSize: 13, color: '#4a3f38', fontWeight: 500 }}>{projectName}</span>
      <span style={{ color: 'rgba(138, 110, 92, 0.5)', fontSize: 12 }}>▾</span>
      <span style={{
        marginLeft: 8,
        display: 'inline-flex', alignItems: 'center', gap: 6,
        padding: '4px 10px', borderRadius: 9999,
        background: 'rgba(106, 155, 122, 0.12)',
        border: '1px solid rgba(106, 155, 122, 0.30)',
        color: '#3e6b50', fontSize: 9, letterSpacing: '0.18em', textTransform: 'uppercase', fontWeight: 500,
      }}>
        <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#6a9b7a' }} />
        Saved
      </span>
    </div>

    {/* Center — tools */}
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <ToolbarGroup>
        <IconButton icon={Undo2} title="Undo (⌘Z)" />
        <IconButton icon={Redo2} title="Redo (⌘⇧Z)" />
      </ToolbarGroup>
      <ToolbarGroup spaced>
        <IconButton icon={MousePointer2} title="Select (V)" active={activeTool === 'select'} onClick={() => setActiveTool('select')} />
        <IconButton icon={Eraser} title="Eraser (E)" active={activeTool === 'erase'} onClick={() => setActiveTool('erase')} />
        <IconButton icon={Hand} title="Pan (H)" active={activeTool === 'pan'} onClick={() => setActiveTool('pan')} />
        <IconButton icon={Type} title="Text (T)" active={activeTool === 'textbox'} onClick={() => setActiveTool('textbox')} />
        <ToolbarDivider />
        <IconButton icon={Magnet} title="Snapping" active={snap} onClick={() => setSnap(s => !s)} />
        <IconButton icon={Grid} title="Grid" active={grid} onClick={() => setGrid(g => !g)} />
      </ToolbarGroup>
      <ToolbarGroup spaced>
        <IconButton icon={Pencil} title="Pencil (P)" active={activeTool === 'draw'} onClick={() => setActiveTool('draw')} />
        <IconButton icon={PaintBucket} title="Canvas Fill" />
      </ToolbarGroup>
    </div>

    {/* Right — chrome */}
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <ChromeButton icon={Home} onClick={onProjectsClick}>Projects</ChromeButton>
      <IconButton icon={Search} title="Quick Open (⌘K)" />
      <IconButton icon={Keyboard} title="Shortcuts" />
      <IconButton icon={Download} title="Export (⌘E)" />
    </div>
  </header>
);

window.Header = Header;
