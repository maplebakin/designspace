// Bottom 48px status bar.

const StatusPill = ({ children, active, onClick, mono }) => {
  const [hover, setHover] = React.useState(false);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        padding: '4px 10px',
        borderRadius: 9999,
        background: active ? 'rgba(184, 135, 143, 0.14)' : (hover ? 'rgba(255, 253, 249, 0.94)' : 'transparent'),
        border: '1px solid ' + (active ? 'rgba(184, 135, 143, 0.30)' : 'rgba(138, 110, 92, 0.24)'),
        color: active ? '#b8878f' : '#7a6a60',
        fontSize: 10, letterSpacing: mono ? 0 : '0.18em', textTransform: mono ? 'none' : 'uppercase', fontWeight: 500,
        fontFamily: mono ? 'var(--font-mono)' : 'inherit',
        cursor: 'pointer', transition: 'all 150ms ease-out',
      }}
    >
      {children}
    </button>
  );
};

const StatusBar = ({ width, height, unit, setUnit, zoom, setZoom, safe, setSafe }) => {
  const dim = unit === 'px' ? `${width} × ${height} PX` : unit === 'in' ? `${(width/96).toFixed(2)} × ${(height/96).toFixed(2)} IN` : `${(width*0.2645).toFixed(0)} × ${(height*0.2645).toFixed(0)} MM`;
  return (
    <div style={{
      height: 48, flexShrink: 0,
      borderTop: '1px solid rgba(138, 110, 92, 0.24)',
      background: 'rgba(255, 249, 241, 0.84)',
      backdropFilter: 'blur(12px)',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 16px',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <StatusPill mono>{dim}</StatusPill>
        <div style={{ display: 'flex', gap: 0, padding: 2, borderRadius: 9999, background: 'rgba(255, 251, 246, 0.78)', border: '1px solid rgba(138, 110, 92, 0.24)' }}>
          {['px', 'in', 'mm'].map(u => (
            <StatusPill key={u} active={unit === u} onClick={() => setUnit(u)}>{u}</StatusPill>
          ))}
        </div>
        <StatusPill active={safe} onClick={() => setSafe(s => !s)}>Safe Zones</StatusPill>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ fontSize: 9, letterSpacing: '0.18em', textTransform: 'uppercase', color: '#7a6a60' }}>Saved 2 min ago</span>
        <div style={{ width: 1, height: 18, background: 'rgba(138, 110, 92, 0.24)' }} />
        <IconButton icon={ZoomOut} title="Zoom out" onClick={() => setZoom(z => Math.max(0.25, z - 0.1))} size={14} />
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: '#4a3f38', minWidth: 40, textAlign: 'center' }}>{Math.round(zoom * 100)}%</span>
        <IconButton icon={ZoomIn} title="Zoom in" onClick={() => setZoom(z => Math.min(4, z + 0.1))} size={14} />
        <IconButton icon={Maximize2} title="Fit to screen" onClick={() => setZoom(1)} size={14} />
      </div>
    </div>
  );
};

window.StatusBar = StatusBar;
