// Center stage — the workspace canvas with paper, grid overlay, and a sample composition.

const CanvasStage = ({ width, height, zoom, gridEnabled, layers, selectedId, onSelect }) => {
  return (
    <main style={{
      flex: 1,
      position: 'relative',
      overflow: 'hidden',
      backgroundColor: '#efe5d9',
      backgroundImage: 'linear-gradient(to right, rgba(120,93,74,0.065) 1px, transparent 1px), linear-gradient(to bottom, rgba(120,93,74,0.065) 1px, transparent 1px)',
      backgroundSize: '24px 24px',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      {/* Rulers — top */}
      <div style={{ position: 'absolute', top: 0, left: 36, right: 0, height: 24, background: 'rgba(255, 249, 241, 0.84)', borderBottom: '1px solid rgba(138, 110, 92, 0.24)', display: 'flex', alignItems: 'flex-end' }}>
        <RulerTicks horizontal />
      </div>
      <div style={{ position: 'absolute', top: 0, left: 0, bottom: 0, width: 36, background: 'rgba(255, 249, 241, 0.84)', borderRight: '1px solid rgba(138, 110, 92, 0.24)' }}>
        <RulerTicks />
      </div>

      {/* Paper */}
      <div style={{ transform: `scale(${zoom})`, transformOrigin: 'center', transition: 'transform 200ms ease-out' }}>
        <div style={{
          width, height,
          background: '#fff',
          borderRadius: 4,
          boxShadow: '0 28px 70px rgba(74, 56, 45, 0.26), 0 6px 16px rgba(74, 56, 45, 0.10)',
          position: 'relative',
          overflow: 'hidden',
          backgroundImage: gridEnabled ? 'linear-gradient(to right, rgba(120,93,74,0.10) 1px, transparent 1px), linear-gradient(to bottom, rgba(120,93,74,0.10) 1px, transparent 1px)' : 'none',
          backgroundSize: '24px 24px',
        }}>
          {layers.map(layer => (
            <CanvasLayer key={layer.id} layer={layer} selected={layer.id === selectedId} onClick={() => onSelect(layer.id)} />
          ))}
        </div>
      </div>

      {/* Selection toolbar (top-center floating) */}
      <div style={{ position: 'absolute', top: 38, left: '50%', transform: 'translateX(-50%)' }}>
        <ToolbarGroup>
          <IconButton icon={Layout} title="Align" />
          <IconButton icon={Pin} title="Pin to Vision" />
          <ToolbarDivider />
          <IconButton icon={Trash2} title="Delete" />
        </ToolbarGroup>
      </div>
    </main>
  );
};

const RulerTicks = ({ horizontal }) => {
  const ticks = [];
  for (let i = 0; i < 60; i++) {
    const isMajor = i % 5 === 0;
    if (horizontal) {
      ticks.push(
        <div key={i} style={{
          width: 1, height: isMajor ? 10 : 5,
          background: 'rgba(122, 106, 96, 0.45)',
          marginLeft: 23,
        }} />
      );
    } else {
      ticks.push(
        <div key={i} style={{
          height: 1, width: isMajor ? 10 : 5,
          background: 'rgba(122, 106, 96, 0.45)',
          marginTop: 23,
        }} />
      );
    }
  }
  return (
    <div style={{
      display: 'flex',
      flexDirection: horizontal ? 'row' : 'column',
      paddingLeft: horizontal ? 12 : 0,
      paddingTop: horizontal ? 0 : 12,
      alignItems: horizontal ? 'flex-end' : 'flex-start',
    }}>{ticks}</div>
  );
};

const CanvasLayer = ({ layer, selected, onClick }) => {
  const ring = selected ? { outline: '2px solid #b8878f', outlineOffset: 2 } : {};
  if (layer.type === 'text') {
    return (
      <div onClick={onClick} style={{
        position: 'absolute', left: layer.x, top: layer.y,
        fontFamily: layer.font || 'var(--font-display)',
        fontSize: layer.size,
        color: layer.fill,
        fontWeight: layer.weight || 600,
        letterSpacing: layer.tracking || '-0.01em',
        cursor: 'pointer',
        ...ring,
      }}>{layer.text}</div>
    );
  }
  if (layer.type === 'rect') {
    return (
      <div onClick={onClick} style={{
        position: 'absolute', left: layer.x, top: layer.y,
        width: layer.w, height: layer.h,
        background: layer.fill,
        borderRadius: layer.radius || 0,
        cursor: 'pointer',
        ...ring,
      }} />
    );
  }
  if (layer.type === 'circle') {
    return (
      <div onClick={onClick} style={{
        position: 'absolute', left: layer.x, top: layer.y,
        width: layer.w, height: layer.h,
        background: layer.fill,
        borderRadius: '50%',
        cursor: 'pointer',
        ...ring,
      }} />
    );
  }
  if (layer.type === 'star') {
    return (
      <div onClick={onClick} style={{ position: 'absolute', left: layer.x, top: layer.y, color: layer.fill, cursor: 'pointer', ...ring }}>
        <Sparkles size={layer.w || 64} />
      </div>
    );
  }
  return null;
};

window.CanvasStage = CanvasStage;
