// Right rail — Layers / Properties / Style tabs.

const RightTab = ({ icon: Icon, label, active, onClick }) => {
  const [hover, setHover] = React.useState(false);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        flex: 1,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6,
        padding: '11px 12px',
        background: active ? 'rgba(184, 135, 143, 0.14)' : (hover ? 'rgba(184, 135, 143, 0.06)' : 'transparent'),
        color: active ? '#b8878f' : '#7a6a60',
        border: 'none',
        borderBottom: active ? '2px solid #b8878f' : '2px solid transparent',
        marginBottom: -1,
        fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase', fontWeight: 500,
        cursor: 'pointer', transition: 'all 200ms ease-out',
        fontFamily: 'inherit',
      }}
    >
      <Icon size={14} />
      {label}
    </button>
  );
};

const LayerRow = ({ layer, selected, onSelect }) => {
  const [hover, setHover] = React.useState(false);
  const TypeIcon = layer.type === 'text' ? Type : layer.type === 'rect' ? Square : layer.type === 'circle' ? Circle : layer.type === 'star' ? Star : Frame;
  return (
    <div
      onClick={onSelect}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: 'flex', alignItems: 'center', gap: 10,
        padding: '8px 12px',
        background: selected ? 'rgba(184, 135, 143, 0.14)' : (hover ? 'rgba(184, 135, 143, 0.06)' : 'transparent'),
        borderLeft: selected ? '2px solid #b8878f' : '2px solid transparent',
        cursor: 'pointer',
        transition: 'all 150ms ease-out',
      }}
    >
      <TypeIcon size={14} />
      <span style={{ fontSize: 12, color: selected ? '#b8878f' : '#4a3f38', flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
        {layer.name}
      </span>
      <Eye size={12} style={{ opacity: 0.5 }} />
      <Lock size={12} style={{ opacity: 0.4 }} />
    </div>
  );
};

const LayersPanel = ({ layers, selectedId, onSelect }) => (
  <div>
    <div style={{ padding: '10px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid rgba(138, 110, 92, 0.18)' }}>
      <Eyebrow size={9}>{layers.length} Layer{layers.length !== 1 ? 's' : ''}</Eyebrow>
      <Eyebrow size={9} color="rgba(122, 106, 96, 0.6)">Top to Bottom</Eyebrow>
    </div>
    {[...layers].reverse().map(l => (
      <LayerRow key={l.id} layer={l} selected={l.id === selectedId} onSelect={() => onSelect(l.id)} />
    ))}
  </div>
);

const PropRow = ({ label, children }) => (
  <div style={{ display: 'grid', gridTemplateColumns: '70px 1fr', alignItems: 'center', gap: 10, marginBottom: 10 }}>
    <Eyebrow size={9} color="rgba(122, 106, 96, 0.85)">{label}</Eyebrow>
    {children}
  </div>
);

const NumInput = ({ value, suffix }) => (
  <div style={{
    display: 'inline-flex', alignItems: 'center',
    padding: '6px 10px',
    borderRadius: 9999,
    background: 'rgba(255, 251, 246, 0.78)',
    border: '1px solid rgba(138, 110, 92, 0.24)',
    fontFamily: 'var(--font-mono)',
    fontSize: 11,
    color: '#4a3f38',
    height: 28, boxSizing: 'border-box',
  }}>
    <span>{value}</span>
    {suffix && <span style={{ marginLeft: 4, opacity: 0.5 }}>{suffix}</span>}
  </div>
);

const SwatchInput = ({ color }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
    <span style={{ width: 22, height: 22, borderRadius: 9999, background: color, border: '1px solid rgba(138, 110, 92, 0.24)' }} />
    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: '#4a3f38' }}>{color}</span>
  </div>
);

const PropertiesPanel = ({ layer }) => {
  if (!layer) return <div style={{ padding: 18 }}><Eyebrow size={9} color="rgba(122, 106, 96, 0.6)">Nothing selected.</Eyebrow></div>;
  return (
    <div style={{ padding: 16 }}>
      <Eyebrow size={9}>Position</Eyebrow>
      <div style={{ marginTop: 10 }}>
        <PropRow label="X / Y"><div style={{ display: 'flex', gap: 6 }}><NumInput value={layer.x ?? 120} suffix="px" /><NumInput value={layer.y ?? 96} suffix="px" /></div></PropRow>
        <PropRow label="Size"><div style={{ display: 'flex', gap: 6 }}><NumInput value={layer.w ?? 320} suffix="px" /><NumInput value={layer.h ?? 200} suffix="px" /></div></PropRow>
        <PropRow label="Rotate"><NumInput value={layer.rotate ?? 0} suffix="°" /></PropRow>
      </div>
      <div style={{ height: 1, background: 'rgba(138, 110, 92, 0.18)', margin: '16px 0' }} />
      <Eyebrow size={9}>Appearance</Eyebrow>
      <div style={{ marginTop: 10 }}>
        <PropRow label="Fill"><SwatchInput color={layer.fill ?? '#b8878f'} /></PropRow>
        <PropRow label="Stroke"><SwatchInput color={layer.stroke ?? '#4a3f38'} /></PropRow>
        <PropRow label="Radius"><NumInput value={layer.radius ?? 12} suffix="px" /></PropRow>
        <PropRow label="Opacity"><NumInput value={layer.opacity ?? 100} suffix="%" /></PropRow>
      </div>
    </div>
  );
};

const StylePanel = () => (
  <div style={{ padding: 16 }}>
    <Eyebrow size={9}>Theme</Eyebrow>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginTop: 10 }}>
      {[
        { name: 'Midnight', bg: '#f6efe6', accent: '#b8878f' },
        { name: 'Hedge', bg: '#eef1ea', accent: '#8ea591' },
        { name: 'Dawn', bg: '#fbf5f1', accent: '#c59aa0' },
      ].map((t, i) => (
        <div key={t.name} style={{
          padding: 10, borderRadius: 12,
          background: t.bg,
          border: i === 0 ? '1px solid #b8878f' : '1px solid rgba(138, 110, 92, 0.24)',
          cursor: 'pointer',
        }}>
          <div style={{ height: 24, borderRadius: 6, background: t.accent, marginBottom: 8 }} />
          <Eyebrow size={9} color="#4a3f38">{t.name}</Eyebrow>
        </div>
      ))}
    </div>
    <div style={{ height: 1, background: 'rgba(138, 110, 92, 0.18)', margin: '16px 0' }} />
    <Eyebrow size={9}>Vibe Settings</Eyebrow>
    <div style={{ marginTop: 10, padding: 12, borderRadius: 12, background: 'rgba(255, 251, 246, 0.78)', border: '1px solid rgba(138, 110, 92, 0.24)' }}>
      <div style={{ fontSize: 12, color: '#4a3f38', marginBottom: 6 }}>Cozy & calm</div>
      <div style={{ fontSize: 11, color: '#7a6a60' }}>Warm-paper backgrounds, sparkle accents, soft rose palette.</div>
    </div>
  </div>
);

const RightPanel = ({ tab, setTab, layers, selectedId, onSelect }) => (
  <aside style={{
    width: 320,
    background: 'rgba(255, 249, 241, 0.70)',
    backdropFilter: 'blur(12px)',
    borderLeft: '1px solid rgba(138, 110, 92, 0.24)',
    display: 'flex', flexDirection: 'column',
    flexShrink: 0,
  }}>
    <div style={{ display: 'flex', borderBottom: '1px solid rgba(138, 110, 92, 0.24)' }}>
      <RightTab icon={Layers} label="Layers" active={tab === 'layers'} onClick={() => setTab('layers')} />
      <RightTab icon={Square} label="Properties" active={tab === 'properties'} onClick={() => setTab('properties')} />
      <RightTab icon={Sparkles} label="Style" active={tab === 'style'} onClick={() => setTab('style')} />
    </div>
    <div style={{ flex: 1, overflowY: 'auto' }}>
      {tab === 'layers' && <LayersPanel layers={layers} selectedId={selectedId} onSelect={onSelect} />}
      {tab === 'properties' && <PropertiesPanel layer={layers.find(l => l.id === selectedId)} />}
      {tab === 'style' && <StylePanel />}
    </div>
  </aside>
);

window.RightPanel = RightPanel;
