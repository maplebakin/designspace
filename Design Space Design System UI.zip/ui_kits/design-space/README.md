# Design Space — UI Kit

Pixel-faithful recreation of the Design Space / DSGN Studio in-browser editor. Split into one screen (the editor) and a dashboard, both reachable from `index.html` via a screen toggle.

## Files

- `index.html` — entry point, mounts React, hosts both screens
- `tokens.js` — copies design tokens onto window for components to consume
- `Icons.jsx` — Lucide-style SVG icon components (stroke 1.5)
- `ChromeButton.jsx` — pill-shaped chrome button + icon button + toolbar group
- `Header.jsx` — top toolbar (DSGN Studio wordmark, project name, tools, chrome)
- `Sidebar.jsx` — left rail (NavStrip + active panel content)
- `RightPanel.jsx` — right rail (Layers / Properties / Style tabs)
- `StatusBar.jsx` — bottom status bar (zoom, dimensions, units, save)
- `PageStrip.jsx` — bottom page strip
- `CanvasStage.jsx` — center stage with paper + sample artwork
- `Dashboard.jsx` — Project Dashboard screen (hero card + recents)
- `EditorShell.jsx` — composes Header / Sidebar / Canvas / RightPanel / Status / PageStrip

## Caveats

- Recreated visually from `src/editor/components/*`. Component implementations are simplified (no Fabric.js, no Zustand) — interactions are local React state.
- Sample artwork on the canvas is a static SVG mock, not a live Fabric scene.
- Lucide icons are inlined as SVG; the source uses `lucide-react` imports.
