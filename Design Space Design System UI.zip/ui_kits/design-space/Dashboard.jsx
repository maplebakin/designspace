// Project Dashboard — the landing screen.

const ProjectRow = ({ project, onOpen }) => {
  const [hover, setHover] = React.useState(false);
  const formatDate = d => new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' }).format(d);
  return (
    <div
      onClick={onOpen}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: 'flex', alignItems: 'center', gap: 14,
        padding: '12px 14px',
        borderRadius: 14,
        background: hover ? 'rgba(255, 253, 249, 0.94)' : 'rgba(255, 251, 246, 0.50)',
        border: '1px solid rgba(138, 110, 92, 0.24)',
        boxShadow: hover ? '0 18px 42px rgba(74, 56, 45, 0.16)' : '0 12px 28px rgba(74, 56, 45, 0.06)',
        cursor: 'pointer',
        transition: 'all 200ms ease-out',
      }}
    >
      <div style={{
        width: 56, height: 56, borderRadius: 10,
        background: project.thumbBg || '#fff',
        border: '1px solid rgba(138, 110, 92, 0.18)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: project.accent || '#b8878f',
        flexShrink: 0,
      }}>
        {project.glyph}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 14, color: '#4a3f38', fontWeight: 500, marginBottom: 4 }}>{project.name}</div>
        <Eyebrow size={9} color="rgba(122, 106, 96, 0.7)">{formatDate(project.lastModified)}</Eyebrow>
      </div>
      <div style={{ opacity: hover ? 1 : 0, transition: 'opacity 150ms ease-out' }}>
        <IconButton icon={Pencil} title="Rename" size={14} />
      </div>
    </div>
  );
};

const Dashboard = ({ projects, onNew, onOpen }) => {
  const [showAll, setShowAll] = React.useState(false);
  const display = showAll ? projects : projects.slice(0, 5);
  return (
    <div style={{
      minHeight: '100vh',
      background: 'radial-gradient(circle at 20% 10%, #fff8ef 0%, #fbf7f2 35%, #efe6dc 100%)',
      color: '#4a3f38',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 24,
      fontFamily: 'var(--font-ui)',
    }}>
      <div style={{
        width: '100%', maxWidth: 880,
        borderRadius: 32,
        border: '1px solid rgba(138, 110, 92, 0.24)',
        background: 'rgba(255, 249, 241, 0.88)',
        backdropFilter: 'blur(12px)',
        padding: 40,
        boxShadow: '0 26px 62px rgba(74, 56, 45, 0.22)',
      }}>
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={{
            width: 56, height: 56, borderRadius: 16,
            background: 'rgba(184, 135, 143, 0.20)', color: '#b8878f',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 14px',
          }}>
            <Sparkles size={26} />
          </div>
          <h1 style={{ fontSize: 36, fontWeight: 600, letterSpacing: '0.02em', margin: 0, fontFamily: 'var(--font-display)' }}>Design Space</h1>
          <p style={{ color: 'rgba(122, 106, 96, 0.85)', marginTop: 12, fontSize: 14 }}>Multi-page design studio</p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 36 }}>
          <button
            onClick={onNew}
            style={{
              height: 48, borderRadius: 12,
              background: 'rgba(184, 135, 143, 0.14)',
              border: '1px solid rgba(184, 135, 143, 0.35)',
              color: '#b8878f',
              fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase', fontWeight: 500,
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              cursor: 'pointer', transition: 'all 200ms ease-out',
              fontFamily: 'inherit',
            }}
            onMouseEnter={e => e.currentTarget.style.background = 'rgba(184, 135, 143, 0.22)'}
            onMouseLeave={e => e.currentTarget.style.background = 'rgba(184, 135, 143, 0.14)'}
          >
            <Plus size={14} /> New Project
          </button>
          <button
            style={{
              height: 48, borderRadius: 12,
              background: 'rgba(255, 251, 246, 0.78)',
              border: '1px solid rgba(138, 110, 92, 0.24)',
              color: '#7a6a60',
              fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase', fontWeight: 500,
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              cursor: 'pointer', transition: 'all 200ms ease-out',
              fontFamily: 'inherit',
            }}
            onMouseEnter={e => e.currentTarget.style.background = 'rgba(255, 253, 249, 0.94)'}
            onMouseLeave={e => e.currentTarget.style.background = 'rgba(255, 251, 246, 0.78)'}
          >
            <FolderOpen size={14} /> Open Project
          </button>
        </div>

        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <Eyebrow size={11} color="#7a6a60">Recent Projects Library</Eyebrow>
            <Eyebrow size={10} color="rgba(122, 106, 96, 0.6)">{projects.length} project{projects.length !== 1 ? 's' : ''}</Eyebrow>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {display.map(p => (<ProjectRow key={p.id} project={p} onOpen={() => onOpen(p)} />))}
          </div>
          {projects.length > 5 && (
            <button
              onClick={() => setShowAll(s => !s)}
              style={{
                marginTop: 14, width: '100%',
                padding: '10px 16px', borderRadius: 12,
                background: 'transparent', border: 'none',
                color: '#7a6a60',
                fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', fontWeight: 500,
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                cursor: 'pointer',
                fontFamily: 'inherit',
              }}
            >
              {showAll ? 'Show Less' : `Show ${projects.length - 5} More`}
              {showAll ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

window.Dashboard = Dashboard;
