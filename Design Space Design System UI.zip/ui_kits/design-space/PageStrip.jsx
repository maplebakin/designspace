// Bottom page strip — page thumbnails + add button.

const PageThumb = ({ index, active, onClick, onDelete, removable }) => {
  const [hover, setHover] = React.useState(false);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        position: 'relative',
        flexShrink: 0,
        width: 100, height: 72,
        borderRadius: 12, padding: 4,
        background: active ? 'rgba(184, 135, 143, 0.14)' : 'rgba(255, 251, 246, 0.50)',
        border: active ? '1px solid #b8878f' : '1px solid rgba(138, 110, 92, 0.24)',
        textAlign: 'left',
        cursor: 'pointer',
        transition: 'all 200ms ease-out',
        boxShadow: active ? '0 12px 28px rgba(74, 56, 45, 0.10)' : 'none',
        fontFamily: 'inherit',
      }}
    >
      <div style={{
        width: '100%', height: 44, borderRadius: 6,
        background: '#fff', border: '1px solid rgba(138, 110, 92, 0.18)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        {index === 0 && <div style={{ width: 30, height: 6, borderRadius: 9999, background: '#b8878f', opacity: 0.45 }} />}
        {index === 1 && <div style={{ display: 'flex', gap: 3 }}><div style={{ width: 8, height: 8, background: '#8fa28d', borderRadius: 2 }} /><div style={{ width: 8, height: 8, background: '#d6a05a', borderRadius: 2 }} /></div>}
        {index === 2 && <div style={{ width: 12, height: 12, borderRadius: '50%', background: '#c4969a' }} />}
      </div>
      <div style={{ marginTop: 4 }}><Eyebrow size={9} color={active ? '#b8878f' : '#7a6a60'}>Page {index + 1}</Eyebrow></div>
      {removable && hover && (
        <span
          onClick={e => { e.stopPropagation(); onDelete?.(); }}
          style={{
            position: 'absolute', top: 4, right: 4,
            width: 18, height: 18, borderRadius: 9999,
            background: 'rgba(74, 56, 45, 0.7)', color: '#fbf7f2',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          }}
        >
          <Trash2 size={10} />
        </span>
      )}
    </button>
  );
};

const PageStrip = ({ pages, activeIndex, setActive, onAdd, onDelete }) => (
  <div style={{
    height: 92, flexShrink: 0,
    borderTop: '1px solid rgba(138, 110, 92, 0.24)',
    background: 'rgba(255, 249, 241, 0.80)',
    backdropFilter: 'blur(12px)',
    padding: '10px 14px',
    display: 'flex', alignItems: 'center', gap: 10,
    overflowX: 'auto',
  }}>
    {pages.map((p, i) => (
      <PageThumb
        key={p.id}
        index={i}
        active={i === activeIndex}
        onClick={() => setActive(i)}
        onDelete={() => onDelete(i)}
        removable={pages.length > 1}
      />
    ))}
    <button
      onClick={onAdd}
      style={{
        flexShrink: 0,
        width: 40, height: 72,
        borderRadius: 12,
        border: '1px dashed rgba(138, 110, 92, 0.36)',
        background: 'transparent',
        color: '#7a6a60',
        cursor: 'pointer',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        transition: 'all 150ms ease-out',
      }}
      onMouseEnter={e => { e.currentTarget.style.borderColor = '#b8878f'; e.currentTarget.style.color = '#b8878f'; }}
      onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(138, 110, 92, 0.36)'; e.currentTarget.style.color = '#7a6a60'; }}
    >
      <Plus size={16} />
    </button>
  </div>
);

window.PageStrip = PageStrip;
