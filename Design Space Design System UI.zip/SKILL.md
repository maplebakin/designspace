---
name: design-space-design
description: Use this skill to generate well-branded interfaces and assets for Design Space (DSGN Studio), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping a warm, paper-textured, multi-page design studio.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick orientation

- **Brand mood:** cozy, calm, slightly precious. Warm cream paper + dusty rose accent + sparkle motif.
- **Defining type treatment:** `uppercase tracking-widest` (letter-spacing 0.18em) on every chrome button, tab, badge, panel header, status pill. Sentence case for body. Title case for page H1s.
- **Default theme is "Midnight" — but it's actually warm cream**, not dark. Don't be misled.
- **Icons are Lucide** (stroke 1.5). No emoji. No Unicode glyphs.
- **No photography, no illustrations.** Imagery is a warm radial gradient + 24px workspace grid.
- **Shadows are warm-tinted** — `rgba(56, 40, 33, α)` or `rgba(74, 56, 45, α)`. Never neutral grey.

## Files in this skill

- `README.md` — full visual + content fundamentals (read this first)
- `colors_and_type.css` — drop-in CSS variables (load with `<link>`)
- `fonts/fonts.css` — Inter + Space Grotesk via Google Fonts
- `assets/` — logo SVGs and icon-strategy notes
- `preview/*.html` — small specimen cards (palettes, type, components) you can copy patterns from
- `ui_kits/design-space/` — JSX components for the editor + dashboard. Load `index.html` to see the full app, or import individual components (`Header.jsx`, `Sidebar.jsx`, `RightPanel.jsx`, `StatusBar.jsx`, `PageStrip.jsx`, `CanvasStage.jsx`, `EditorShell.jsx`, `Dashboard.jsx`, `Icons.jsx`, `ChromeButton.jsx`)

## Common patterns to lift

```html
<link rel="stylesheet" href="colors_and_type.css" />

<!-- Eyebrow label / chrome button -->
<button style="
  padding: 8px 16px; border-radius: 9999px;
  font-size: 11px; letter-spacing: 0.18em; text-transform: uppercase; font-weight: 500;
  background: rgba(255, 251, 246, 0.78);
  border: 1px solid rgba(138, 110, 92, 0.24);
  box-shadow: 0 12px 28px rgba(74, 56, 45, 0.10);
  color: #7a6a60;
">New Project</button>

<!-- Card -->
<div style="
  border-radius: 16px;
  background: rgba(255, 251, 246, 0.78);
  border: 1px solid rgba(138, 110, 92, 0.24);
  box-shadow: 0 12px 28px rgba(74, 56, 45, 0.10);
  backdrop-filter: blur(12px);
  padding: 16px;
"></div>
```

## Don't

- Don't use cool greys, slate-blue, indigo, or saturated brights.
- Don't use sharp 90° corners on interactive elements.
- Don't use heavy display fonts. Inter is the workhorse.
- Don't use neutral-grey shadows.
- Don't use emoji.
- Don't draw icons by hand — use Lucide via CDN or copy from `Icons.jsx`.
